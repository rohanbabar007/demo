package study.servlet;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import study.dao.CustomerDao;
import study.entity.Customer;


@WebServlet("/AddInfo")
public class AddInfoServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
   
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		String fname=request.getParameter("fname");
		String lname=request.getParameter("lname");
		String add=request.getParameter("address");
		Customer customer=new Customer(fname, lname, add);
		CustomerDao dao=new CustomerDao();
		dao.AddInfo(customer);
		response.setContentType("text/html");
		response.getWriter().append("Inserted Successfully!!");
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
