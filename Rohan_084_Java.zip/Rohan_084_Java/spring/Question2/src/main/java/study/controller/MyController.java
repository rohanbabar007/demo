package study.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import study.entity.Product;
import study.repositary.MyRespositary;

@RestController
@RequestMapping("/product")
public class MyController 
{
	@Autowired
	MyRespositary re;
	@GetMapping("/add")
    public void insertProduct(@RequestParam String name,@RequestParam int ratings)
    {
    	Product obj=new Product(name, ratings);
    	re.save(obj);
    }
   
}
