package study.controller;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.servlet.ModelAndView;

import study.repositary.MyRespositary;
@Controller
public class MyWebController {


	@Autowired
	MyRespositary re;
	@GetMapping("/getAllRatings")
	public ModelAndView getallProduct()
	{ 
		
		ModelAndView obj=new ModelAndView();
		obj.addObject("list",re.findAll());
		obj.setViewName("show");
		return obj;

	}
}
