package study.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="product_rating_table")
public class Product
{
  @Id
  @Column
  private String productName;
  @Column
  private int productRating;
  public Product() {
	// TODO Auto-generated constructor stub
}
public Product(String productName, int productRating) {
	super();
	this.productName = productName;
	this.productRating = productRating;
}
public String getProductName() {
	return productName;
}
public void setProductName(String productName) {
	this.productName = productName;
}
public int getProductRating() {
	return productRating;
}
public void setProductRating(int productRating) {
	this.productRating = productRating;
}
@Override
public String toString() {
	return "Product [productName=" + productName + ", productRating=" + productRating + "]";
}
  
}
