package study.repositary;



import org.springframework.data.jpa.repository.JpaRepository;

import org.springframework.stereotype.Repository;

import study.entity.Product;

@Repository
public interface MyRespositary  extends JpaRepository<Product, String>{

  

}
